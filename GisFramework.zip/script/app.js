﻿define(['classutil', 'modulemanager', 'commandmanager', 'commonmodule', 'gis2dmodule'],
    function (classUtil, ModuleManager, CommandManager, commonModule, Gis2dModule) {
        var _app = function () {

        }

        _app.prototype.run = function () {
            var CommandMgr = new CommandManager();

            var moduleMgr = new ModuleManager();

            moduleMgr.add(new commonModule());
            moduleMgr.add(new Gis2dModule());
            moduleMgr.init();

            this.init();
        }

        _app.prototype.init = function () {

        }

        return _app;
    });