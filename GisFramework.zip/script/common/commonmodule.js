﻿/* init home page
*/
define(['classutil', 'modulebase'],
    function (classUtil, ModuleBase) {
        var _module = function (options) {
            var opts = options || {};
            ModuleBase.call(this, opts);
        }

        classUtil.extend2(_module, ModuleBase);

        _module.prototype.createView = function () {

        }

        return _module;
    });