﻿define([],
    function () {
        var _factory = function (options) {
            
        }

        _factory.

    });