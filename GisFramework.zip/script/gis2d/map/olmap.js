﻿define(['map', 'classutil', 'ol'],
    function (Map, classUtil, Ol) {
        var _olmap = function (parameter) {
            var opts = options || {};
            var interactionsCollection = new Ol.Collection();
            this.provider = new Ol.Map({
                view: new Ol.View({
                    center: {},
                    zoom: 4,
                }),
                overlays: [],
                interactions: interactionsCollection,
            });
        } 
    });