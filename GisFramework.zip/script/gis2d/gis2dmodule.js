﻿define(['classutil', 'modulebase'],
    function (classUtil, ModuleBase) {
        var _module = function (options) {

        }

        classUtil.extend2(_module, ModuleBase);

        return _module;
    });