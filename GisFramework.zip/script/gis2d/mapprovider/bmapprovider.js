﻿/* baidu map */
define([],
    function () {

    });