﻿/* openlayer3 
*/
define([], function () {

});