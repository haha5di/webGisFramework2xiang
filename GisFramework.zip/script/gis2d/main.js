﻿require.config({
    paths: { 
        mapprovider: 'gis2d/mapprovider/mapprovider',
        olmapprovider: 'gis2d/mapprovider/olmapprovider',
        bmapprovider: 'gis2d/mapprovider/bmapprovider',
        gmapprovider: 'gis2d/mapprovider/gmapprovider',
        bingmapprovider: 'gis2d/mapprovider/bingmapprovider',

        map: 'gis2d/map/map',
        olmap: 'gis2d/map/olmap',
        ollayer: 'gis2d/layer/ol/ollayer',

        ol: 'lib/ol',
    },
    shim: {
        ol: {
            exports: 'ol',
        }
    },
}); 