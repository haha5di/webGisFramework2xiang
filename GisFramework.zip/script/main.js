/**
 * Created by Xiangliubo on 2014/12/29.
 */
require.config({
    baseUrl: './script',
    packages: ['gis2d', 'common'],
    paths: {
        jquery: 'lib/jquery-1.11.2',
        domready: 'lib/domReady',
        angular: 'lib/angular/Angular',
        ngminerr: 'lib/angular/minErr',
        bootstrap: 'lib/bootstrap/js/bootstrap',
        ////util
        classutil: "util/classutil",
        ////common
        commandmanager: 'common/commandmanager',
        modulemanager: 'common/modulemanager',
        modulebase: 'module/modulebase',
        ////add submodule here
        commonmodule: 'common/commonmodule',
        gis2dmodule: 'gis2d/gis2dmodule',

        app: 'app',
    },
    shim: {
        'angular': {
            deps: ['jquery', 'ngminerr'],
            exports: 'angular',
        },
        'bootstrap': {
            deps: ['jquery'],
            exports: 'bootstrap',
        },
    },
});

require(['domready', 'app', 'gis2d'], function (DomReady, app) {
    //DomReady(function () { 
    var app = new app();
    app.run();
    //});
});